"""
ml/training/train.py
---------------------
Fine-tune distilbert-base-uncased on the job category classification task.

Usage:
    python ml/training/train.py --epochs 5 --batch-size 32 --output-dir ml/models
"""

import argparse
import logging
import os
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import classification_report
from torch.utils.data import DataLoader, Dataset
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    get_linear_schedule_with_warmup,
)

logger = logging.getLogger(__name__)

MODEL_NAME = "distilbert-base-uncased"
LABEL_LIST = [
    "Engineering", "Marketing", "Finance", "Healthcare",
    "Design", "Data Science", "Operations", "Sales",
    "Legal", "Human Resources", "Education", "Other",
]
LABEL2ID = {l: i for i, l in enumerate(LABEL_LIST)}
ID2LABEL = {i: l for l, i in LABEL2ID.items()}


class JobDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_len=256):
        self.encodings = tokenizer(
            texts, truncation=True, padding=True, max_length=max_len
        )
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return {
            key: torch.tensor(val[idx])
            for key, val in self.encodings.items()
        } | {"labels": torch.tensor(self.labels[idx], dtype=torch.long)}


def load_data(data_dir: str):
    """Load TSV files from data_dir/train.tsv and data_dir/val.tsv."""
    import pandas as pd

    train_df = pd.read_csv(os.path.join(data_dir, "train.tsv"), sep="\t")
    val_df = pd.read_csv(os.path.join(data_dir, "val.tsv"), sep="\t")

    train_texts = (train_df["title"] + " [SEP] " + train_df["description"].fillna("")).tolist()
    val_texts = (val_df["title"] + " [SEP] " + val_df["description"].fillna("")).tolist()

    train_labels = [LABEL2ID.get(l, LABEL2ID["Other"]) for l in train_df["category"]]
    val_labels = [LABEL2ID.get(l, LABEL2ID["Other"]) for l in val_df["category"]]

    return train_texts, train_labels, val_texts, val_labels


def train(args):
    logging.basicConfig(level=logging.INFO)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info("Training on: %s", device)

    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=len(LABEL_LIST),
        id2label=ID2LABEL,
        label2id=LABEL2ID,
    ).to(device)

    train_texts, train_labels, val_texts, val_labels = load_data(args.data_dir)

    train_ds = JobDataset(train_texts, train_labels, tokenizer)
    val_ds = JobDataset(val_texts, val_labels, tokenizer)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    total_steps = len(train_loader) * args.epochs
    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=total_steps // 10, num_training_steps=total_steps
    )

    best_val_acc = 0.0
    output_path = Path(args.output_dir) / "classifier_v3.pt"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        # ── Train ────────────────────────────────────────────────────────────
        model.train()
        total_loss = 0.0
        for batch in train_loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            outputs = model(**batch)
            loss = outputs.loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()
            total_loss += loss.item()

        avg_loss = total_loss / len(train_loader)

        # ── Validate ─────────────────────────────────────────────────────────
        model.eval()
        all_preds, all_labels = [], []
        with torch.no_grad():
            for batch in val_loader:
                labels = batch.pop("labels").to(device)
                batch = {k: v.to(device) for k, v in batch.items()}
                logits = model(**batch).logits
                preds = logits.argmax(dim=-1)
                all_preds.extend(preds.cpu().tolist())
                all_labels.extend(labels.cpu().tolist())

        val_acc = np.mean(np.array(all_preds) == np.array(all_labels))
        logger.info("Epoch %d/%d — loss: %.4f — val_acc: %.4f", epoch, args.epochs, avg_loss, val_acc)

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), output_path)
            logger.info("✔ New best model saved (val_acc=%.4f)", best_val_acc)

    print(classification_report(all_labels, all_preds, target_names=LABEL_LIST))
    logger.info("Training complete. Best val_acc: %.4f", best_val_acc)
    logger.info("Model saved to: %s", output_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/training")
    parser.add_argument("--output-dir", default="ml/models")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=2e-5)
    train(parser.parse_args())
