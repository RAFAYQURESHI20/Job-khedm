"""
ml/models/classifier.py
------------------------
BERT-based job category classifier.
Wraps a fine-tuned distilbert-base-uncased model for inference.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from models import JobCategory

logger = logging.getLogger(__name__)

# Ordered label list matching training labels
LABEL_LIST: List[str] = [c.value for c in JobCategory]


class JobClassifier:
    """
    Thin inference wrapper around the fine-tuned DistilBERT classifier.

    Usage:
        clf = JobClassifier("ml/models/classifier_v3.pt")
        results = clf.predict_batch(listings, threshold=0.72)
    """

    def __init__(self, model_path: str, device: Optional[str] = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        logger.info("Loading classifier from %s on %s …", model_path, self.device)

        self.tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
        self.model = AutoModelForSequenceClassification.from_pretrained(
            "distilbert-base-uncased",
            num_labels=len(LABEL_LIST),
        )

        # Load fine-tuned weights
        state = torch.load(model_path, map_location=self.device)
        self.model.load_state_dict(state)
        self.model.to(self.device)
        self.model.eval()
        logger.info("Classifier ready (%d labels).", len(LABEL_LIST))

    def _build_input(self, listing: Dict) -> str:
        title = listing.get("title", "")
        desc = listing.get("description", "")[:512]
        return f"{title} [SEP] {desc}"

    @torch.no_grad()
    def predict_batch(
        self,
        listings: List[Dict],
        threshold: float = 0.72,
        batch_size: int = 32,
    ) -> List[Dict]:
        """
        Classify listings in batches.
        Adds 'category' and 'classification_score' keys to each listing dict.
        Listings below `threshold` get category=OTHER.
        """
        enriched = []
        for i in range(0, len(listings), batch_size):
            batch = listings[i : i + batch_size]
            texts = [self._build_input(l) for l in batch]

            enc = self.tokenizer(
                texts,
                padding=True,
                truncation=True,
                max_length=256,
                return_tensors="pt",
            ).to(self.device)

            logits = self.model(**enc).logits
            probs = torch.softmax(logits, dim=-1).cpu()
            scores, indices = probs.max(dim=-1)

            for listing, score, idx in zip(batch, scores.tolist(), indices.tolist()):
                if score >= threshold:
                    category = LABEL_LIST[idx]
                else:
                    category = JobCategory.OTHER.value
                enriched.append({
                    **listing,
                    "category": category,
                    "classification_score": round(score, 4),
                })

        logger.info("Classified %d listings.", len(enriched))
        return enriched
