"""
daily_automation_system.py
--------------------------
Lightweight scheduler that runs the JobPulse pipeline on a cron schedule
without relying on an external task runner.  Useful for self-hosted setups.

Run this as a long-lived process (e.g. via systemd or screen):
    python daily_automation_system.py
"""

import logging
import subprocess
import sys
import time
from datetime import datetime, timezone

import schedule

logger = logging.getLogger(__name__)
UTC = timezone.utc


def run_pipeline():
    logger.info("Scheduler triggered — launching pipeline at %s", datetime.now(UTC).isoformat())
    result = subprocess.run(
        [sys.executable, "run_daily_pipeline.py", "--sources", "all"],
        capture_output=False,
    )
    if result.returncode != 0:
        logger.error("Pipeline exited with code %d", result.returncode)
    else:
        logger.info("Pipeline completed successfully.")


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    # Schedule at 02:00 UTC every day
    schedule.every().day.at("02:00").do(run_pipeline)
    logger.info("Daily automation system started. Waiting for scheduled run at 02:00 UTC …")

    while True:
        schedule.run_pending()
        time.sleep(30)


if __name__ == "__main__":
    main()
