"""
config.py
---------
Central configuration loader using pydantic-settings.
All values can be overridden via environment variables or a .env file.
"""

from functools import lru_cache
from typing import List, Optional

from pydantic import Field, PostgresDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── App ──────────────────────────────────────────────────────────────
    APP_NAME: str = "JobPulse"
    APP_VERSION: str = "1.4.2"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"

    # ── Database ─────────────────────────────────────────────────────────
    DATABASE_URL: PostgresDsn = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/jobpulse",
        description="Async PostgreSQL connection string.",
    )
    DB_POOL_SIZE: int = 10
    DB_POOL_OVERFLOW: int = 5
    DB_ECHO: bool = False

    # ── Redis / Cache ─────────────────────────────────────────────────────
    REDIS_URL: Optional[str] = None
    CACHE_TTL_SECONDS: int = 3600

    # ── API ───────────────────────────────────────────────────────────────
    API_V1_PREFIX: str = "/api/v1"
    SECRET_KEY: str = Field(default="change-me-in-production", min_length=16)
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 1 day
    CORS_ORIGINS: List[str] = ["http://localhost:5173", "https://jobpulse.vercel.app"]

    # ── Scraper ───────────────────────────────────────────────────────────
    PROXY_URL: Optional[str] = None
    SCRAPER_DELAY_MIN: float = 1.5
    SCRAPER_DELAY_MAX: float = 4.0
    MAX_PAGES_PER_SOURCE: int = 20
    USER_AGENT_ROTATE: bool = True

    # ── ML ────────────────────────────────────────────────────────────────
    MODEL_PATH: str = "ml/models/classifier_v3.pt"
    CLASSIFICATION_BATCH_SIZE: int = 64
    CLASSIFICATION_THRESHOLD: float = 0.72

    # ── Notifications ─────────────────────────────────────────────────────
    SLACK_WEBHOOK_URL: Optional[str] = None
    NOTIFY_ON_ERROR: bool = True

    # ── Validators ────────────────────────────────────────────────────────
    @field_validator("LOG_LEVEL")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        v = v.upper()
        if v not in allowed:
            raise ValueError(f"LOG_LEVEL must be one of {allowed}")
        return v


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings: Settings = get_settings()
