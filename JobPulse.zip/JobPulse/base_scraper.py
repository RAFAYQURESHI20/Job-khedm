"""
base_scraper.py
---------------
Abstract base class for all JobPulse scrapers.
All source-specific scrapers must inherit from BaseScraper and implement
the `fetch_listings()` method.
"""

import time
import logging
import random
from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from datetime import datetime

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import settings

logger = logging.getLogger(__name__)


class ScraperError(Exception):
    """Raised when a scraper encounters an unrecoverable error."""
    pass


class BaseScraper(ABC):
    """
    Abstract base class providing shared HTTP, retry, and proxy logic
    for all job board scrapers.
    """

    DEFAULT_HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
    }

    def __init__(
        self,
        source_name: str,
        base_url: str,
        use_proxy: bool = False,
        delay_range: tuple = (1.5, 3.5),
    ):
        self.source_name = source_name
        self.base_url = base_url
        self.use_proxy = use_proxy
        self.delay_range = delay_range
        self.session = self._build_session()
        self.scraped_at = datetime.utcnow().isoformat()

    # ------------------------------------------------------------------
    # Session / HTTP helpers
    # ------------------------------------------------------------------

    def _build_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update(self.DEFAULT_HEADERS)

        retry_strategy = Retry(
            total=4,
            backoff_factor=1.2,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)

        if self.use_proxy and settings.PROXY_URL:
            session.proxies = {
                "http": settings.PROXY_URL,
                "https": settings.PROXY_URL,
            }
            logger.debug("Proxy configured: %s", settings.PROXY_URL)

        return session

    def _get(self, url: str, params: Optional[Dict] = None, **kwargs) -> requests.Response:
        """GET with polite delay and error handling."""
        time.sleep(random.uniform(*self.delay_range))
        try:
            resp = self.session.get(url, params=params, timeout=20, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.RequestException as exc:
            logger.error("[%s] GET failed for %s — %s", self.source_name, url, exc)
            raise ScraperError(str(exc)) from exc

    def _post(self, url: str, json: Optional[Dict] = None, **kwargs) -> requests.Response:
        """POST with polite delay and error handling."""
        time.sleep(random.uniform(*self.delay_range))
        try:
            resp = self.session.post(url, json=json, timeout=20, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.RequestException as exc:
            logger.error("[%s] POST failed for %s — %s", self.source_name, url, exc)
            raise ScraperError(str(exc)) from exc

    # ------------------------------------------------------------------
    # Normalisation helpers
    # ------------------------------------------------------------------

    @staticmethod
    def clean_text(text: Optional[str]) -> str:
        if not text:
            return ""
        return " ".join(text.split()).strip()

    @staticmethod
    def normalize_salary(raw: Optional[str]) -> Optional[str]:
        """Best-effort salary string normalisation."""
        if not raw:
            return None
        raw = raw.strip().replace("\u00a0", " ")
        return raw if raw else None

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def fetch_listings(self) -> List[Dict]:
        """
        Scrape the source and return a list of normalised job dicts.

        Each dict must contain at minimum:
            title       (str)
            company     (str)
            location    (str)
            url         (str)
            source      (str)  — set to self.source_name
            scraped_at  (str)  — ISO-8601 UTC timestamp
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Run entry-point
    # ------------------------------------------------------------------

    def run(self) -> List[Dict]:
        logger.info("[%s] Starting scrape …", self.source_name)
        try:
            listings = self.fetch_listings()
            logger.info("[%s] Finished — %d listings collected.", self.source_name, len(listings))
            return listings
        except ScraperError as exc:
            logger.error("[%s] Scrape aborted: %s", self.source_name, exc)
            return []
