"""
scrapers/parsers/generic_api.py
--------------------------------
Scraper for job boards that expose a JSON REST API.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

from base_scraper import BaseScraper
from config import settings

logger = logging.getLogger(__name__)


class GenericAPIParser(BaseScraper):
    """
    Scraper for paginated JSON APIs.

    Supports both page-number pagination and offset-based pagination.
    """

    def __init__(
        self,
        source_name: str,
        base_url: str,
        results_key: str = "results",
        page_param: str = "page",
        page_size_param: str = "limit",
        page_size: int = 50,
        use_offset: bool = False,
        extra_params: Optional[Dict] = None,
        **kwargs,
    ):
        super().__init__(source_name=source_name, base_url=base_url, **kwargs)
        self.results_key = results_key
        self.page_param = page_param
        self.page_size_param = page_size_param
        self.page_size = page_size
        self.use_offset = use_offset
        self.extra_params = extra_params or {}
        self._max_pages = settings.MAX_PAGES_PER_SOURCE

    # ------------------------------------------------------------------

    def _build_params(self, page_or_offset: int) -> Dict:
        params = {
            self.page_size_param: self.page_size,
            **self.extra_params,
        }
        if self.use_offset:
            params[self.page_param] = page_or_offset * self.page_size
        else:
            params[self.page_param] = page_or_offset
        return params

    def _parse_listing(self, raw: Dict) -> Optional[Dict]:
        """Map source-specific keys to the canonical listing schema."""
        title = self.clean_text(
            raw.get("title") or raw.get("job_title") or raw.get("name")
        )
        company = self.clean_text(
            raw.get("company") or raw.get("employer") or raw.get("organization")
        )
        url = raw.get("url") or raw.get("link") or raw.get("apply_url") or ""

        if not title or not url:
            return None

        return {
            "title": title,
            "company": company or "—",
            "location": self.clean_text(raw.get("location") or raw.get("city") or ""),
            "salary_raw": self.normalize_salary(raw.get("salary") or raw.get("salary_range")),
            "description": self.clean_text(raw.get("description") or raw.get("summary") or ""),
            "url": url,
            "external_id": str(raw.get("id") or raw.get("job_id") or ""),
            "source": self.source_name,
            "scraped_at": self.scraped_at,
        }

    def fetch_listings(self) -> List[Dict]:
        listings = []

        for page in range(1, self._max_pages + 1):
            params = self._build_params(page)
            try:
                resp = self._get(self.base_url, params=params)
                data = resp.json()
            except Exception as exc:
                logger.warning("[%s] Page %d error: %s", self.source_name, page, exc)
                break

            # Handle both list and nested-dict responses
            raw_items = data if isinstance(data, list) else data.get(self.results_key, [])

            if not raw_items:
                logger.debug("[%s] No more results at page %d.", self.source_name, page)
                break

            for item in raw_items:
                parsed = self._parse_listing(item)
                if parsed:
                    listings.append(parsed)

            logger.debug("[%s] Page %d — %d items (running total: %d)", self.source_name, page, len(raw_items), len(listings))

            # If fewer results than page_size, we've hit the last page
            if len(raw_items) < self.page_size:
                break

        return listings
