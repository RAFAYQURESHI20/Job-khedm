"""
scrapers/parsers/html_parser.py
--------------------------------
Scraper for job boards that serve paginated HTML listings.
Uses BeautifulSoup for extraction.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from base_scraper import BaseScraper
from config import settings

logger = logging.getLogger(__name__)


class HTMLParser(BaseScraper):
    """
    CSS-selector-based HTML scraper with auto next-page following.
    """

    def __init__(
        self,
        source_name: str,
        base_url: str,
        listing_selector: str,
        title_selector: str = "h2, h3, .job-title, [class*='title']",
        company_selector: str = ".company, [class*='company'], [class*='employer']",
        location_selector: str = ".location, [class*='location'], [class*='city']",
        salary_selector: str = ".salary, [class*='salary']",
        link_selector: str = "a",
        next_page_selector: str = "a.next, a[rel='next'], .pagination__next a",
        **kwargs,
    ):
        super().__init__(source_name=source_name, base_url=base_url, **kwargs)
        self.listing_sel = listing_selector
        self.title_sel = title_selector
        self.company_sel = company_selector
        self.location_sel = location_selector
        self.salary_sel = salary_selector
        self.link_sel = link_selector
        self.next_page_sel = next_page_selector
        self._max_pages = settings.MAX_PAGES_PER_SOURCE

    # ------------------------------------------------------------------

    def _soup(self, url: str) -> Optional[BeautifulSoup]:
        try:
            resp = self._get(url)
            return BeautifulSoup(resp.text, "lxml")
        except Exception as exc:
            logger.warning("[%s] Failed to fetch %s — %s", self.source_name, url, exc)
            return None

    def _text(self, el, selector: str) -> str:
        tag = el.select_one(selector)
        return self.clean_text(tag.get_text()) if tag else ""

    def _parse_card(self, card, page_url: str) -> Optional[Dict]:
        title = self._text(card, self.title_sel)
        link_tag = card.select_one(self.link_sel)

        if not title or not link_tag:
            return None

        href = link_tag.get("href", "")
        url = urljoin(page_url, href) if href else ""
        if not url:
            return None

        return {
            "title": title,
            "company": self._text(card, self.company_sel) or "—",
            "location": self._text(card, self.location_sel),
            "salary_raw": self.normalize_salary(self._text(card, self.salary_sel)),
            "url": url,
            "source": self.source_name,
            "scraped_at": self.scraped_at,
        }

    def fetch_listings(self) -> List[Dict]:
        listings = []
        current_url = self.base_url
        pages_scraped = 0

        while current_url and pages_scraped < self._max_pages:
            soup = self._soup(current_url)
            if not soup:
                break

            cards = soup.select(self.listing_sel)
            logger.debug("[%s] Page %d — %d cards at %s", self.source_name, pages_scraped + 1, len(cards), current_url)

            for card in cards:
                parsed = self._parse_card(card, current_url)
                if parsed:
                    listings.append(parsed)

            # Follow next page
            next_link = soup.select_one(self.next_page_sel)
            if next_link and next_link.get("href"):
                current_url = urljoin(current_url, next_link["href"])
            else:
                break

            pages_scraped += 1

        return listings
